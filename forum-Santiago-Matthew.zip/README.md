# forum-Santi-Matthew

project 2 for webdev

## Name

Matthew Toledo and Santiago Luna

## Description

In this project, we created a pseudo-forum. We fetched data from a JSON file and created a user interface using react to render its components.

## Attributions

Fonts provided by Google Fonts:
https://fonts.googleapis.com
https://fonts.gstatic.com
https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@300&display=swap
